VTM <-
function(vc, nr){
   matrix(vc, ncol = length(vc), nrow = nr, byrow = T)
}
