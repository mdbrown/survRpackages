Lam.true <-
function(tt){tt}
