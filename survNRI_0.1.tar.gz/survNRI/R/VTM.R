VTM <-
function(vc, dm){
     matrix(vc, ncol=length(vc), nrow=dm, byrow=T)
    }
